<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('Main/Home');
    }
    public function Devices()
    {
        $data =[
            'title' => 'device',
            'device' => [
                [
                    'id' => '001',
                    'device_name' => 'Samsung Galaxy',
                    'device_brand' => 'Samsung',
                    'device_quantity' => '1',
                    'device_status' => '0'
                ],
                [
                    'id' => '002',
                    'device_name' => 'Iphone 12 Pro Max',
                    'device_brand' => 'Apple',
                    'device_quantity' => '2',
                    'device_status' => '1'
                ],
                [
                    'id' => '003',
                    'device_name' => 'Pocophone F1',
                    'device_brand' => 'Redmi',
                    'device_quantity' => '1',
                    'device_status' => '1'
                ]
            ]
        ];

        return view('Main/Devices', $data);
    }
}
